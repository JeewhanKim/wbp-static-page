/* Main Controller */
document.addEventListener("DOMContentLoaded", require('./controllers'))
